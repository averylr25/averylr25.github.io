import dotenv from 'dotenv';
dotenv.config();
import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';

const app = express();
app.use(express.json());

app.use(cors({
  origin: 'http://localhost:5173', credentials: true
}));

mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('Connected to MongoDB'))
.catch(err => console.error('MongoDB connection failed', err));

const DogSchema = new mongoose.Schema({
  breed: { type: String, required: true },
  sex: { type: String, required: true },
  age: { type: String, required: true },
  name: { type: String, required: true },
});
const Dog = mongoose.model('dogs', DogSchema);

const HistorySchema = new mongoose.Schema({
  action: { type: String, enum: ['create', 'update', 'delete'], required: true },
  timestamp: { type: Date, default: Date.now },
  dog: { type: Object, required: true },
  dogId: { type: String, required: true }
});
const History = mongoose.model('dog_history', HistorySchema);

const RedoSchema = new mongoose.Schema({
  action: { type: String, enum: ['create', 'update', 'delete'], required: true },
  timestamp: { type: Date, default: Date.now },
  dog: { type: Object, required: true },
  dogId: { type: String, required: true }
});
const Redo = mongoose.model('redo_history', RedoSchema);

const UserSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true }
});

UserSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

const User = mongoose.model('users', UserSchema);

const SECRET = process.env.JWT_SECRET;

function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.status(401).send({ message: 'Missing token' });
  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(403).send({ message: 'Invalid token' });
  }
}

app.get('/', (req, res) => {
  res.send("Backend is working");
});

// API routes with auth middleware
app.get('/api/dogs', async (req, res) => {
  try {
    const dogs = await Dog.find();
    res.json(dogs);
  } catch (e) {
    res.status(500).send({ message: "Failed to retrieve dogs", error: e.message });
  }
});

app.post('/api/dogs', authMiddleware, async (req, res) => {
  try {
    const dog = new Dog(req.body);
    const result = await dog.save();
    await History.create({ action: 'create', dog: result.toObject(), dogId: result._id.toString() });
    await Redo.deleteMany({});
    res.status(201).send(result);
  } catch (e) {
    res.status(500).send({ message: "Failed to create dog", error: e.message });
  }
});

app.put('/api/dogs/:id', authMiddleware, async (req, res) => {
  try {
    const original = await Dog.findById(req.params.id);
    if (!original) return res.status(404).send({ message: "Dog not found" });

    const updated = await Dog.findByIdAndUpdate(req.params.id, req.body, { new: true });
    await History.create({ action: 'update', dog: original.toObject(), dogId: req.params.id });
    await Redo.deleteMany({});
    res.send(updated);
  } catch (e) {
    res.status(500).send({ message: "Failed to update dog", error: e.message });
  }
});

app.delete('/api/dogs/:id', authMiddleware, async (req, res) => {
  try {
    const dog = await Dog.findById(req.params.id);
    if (!dog) return res.status(404).send({ message: "Dog not found" });

    await History.create({ action: 'delete', dog: dog.toObject(), dogId: req.params.id });
    await Dog.findByIdAndDelete(req.params.id);
    await Redo.deleteMany({});
    res.send({ message: "Dog deleted" });
  } catch (e) {
    res.status(500).send({ message: "Failed to delete dog", error: e.message });
  }
});

app.post('/api/undo', authMiddleware, async (req, res) => {
  try {
    const last = await History.findOne().sort({ timestamp: -1 });
    if (!last) return res.status(404).send({ message: "No undo history found" });

    if (last.action === 'create') {
      await Dog.findByIdAndDelete(last.dogId);
    } else if (last.action === 'update') {
      await Dog.findByIdAndUpdate(last.dogId, last.dog);
    } else if (last.action === 'delete') {
      await Dog.create(last.dog);
    }

    await Redo.create({ action: last.action, dog: last.dog, dogId: last.dogId });
    await History.findByIdAndDelete(last._id);
    res.send({ message: `Undid ${last.action}` });
  } catch (e) {
    res.status(500).send({ message: "Failed to undo", error: e.message });
  }
});

app.post('/api/redo', authMiddleware, async (req, res) => {
  try {
    const last = await Redo.findOne().sort({ timestamp: -1 });
    if (!last) return res.status(404).send({ message: "No redo history found" });

    if (last.action === 'create') {
      await Dog.create(last.dog);
    } else if (last.action === 'update') {
      await Dog.findByIdAndUpdate(last.dogId, last.dog);
    } else if (last.action === 'delete') {
      await Dog.findByIdAndDelete(last.dogId);
    }

    await History.create({ action: last.action, dog: last.dog, dogId: last.dogId });
    await Redo.findByIdAndDelete(last._id);
    res.send({ message: `Redid ${last.action}` });
  } catch (e) {
    res.status(500).send({ message: "Failed to redo", error: e.message });
  }
});

// Auth Routes
app.post('/api/register', async (req, res) => {
  try {
    const { email, password } = req.body;
    const existingUser = await User.findOne({ email });
    if (existingUser) return res.status(400).json({ message: 'User already exists' });
    const newUser = new User({ email, password });
    await newUser.save();
    res.status(201).json({ message: 'User registered successfully' });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(400).send({ message: 'Invalid email or password' });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).send({ message: 'Invalid email or password' });

    const token = jwt.sign({ id: user._id }, SECRET, { expiresIn: '1h' });
    res.json({ token });
  } catch (e) {
    res.status(500).send({ message: 'Login failed', error: e.message });
  }
});

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});