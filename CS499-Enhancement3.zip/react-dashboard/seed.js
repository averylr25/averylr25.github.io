// Import test data for Mongo.
import { MongoClient } from 'mongodb';

async function seedDatabase() {
  const uri = 'mongodb://localhost:27017';
  const client = new MongoClient(uri);

  try {
    await client.connect();
    const db = client.db('rescueDogs');
    const dogs = db.collection('dogs');

    await dogs.deleteMany({}); // Clear old data

    const sampleDogs = [
      { name: 'Buster', breed: 'Water Rescue', sex: 'Male', age: '12 weeks' },
      { name: 'Daisy', breed: 'Mountain Wilderness Rescue', sex: 'Female', age: '23 weeks' },
      { name: 'Chop', breed: 'Disaster Individual Rescue', sex: 'Male', age: '43 weeks' },
      { name: 'Roxy', breed: 'Search and Rescue', sex: 'Female', age: '30 weeks' },
      { name: 'Zeus', breed: 'Urban Search and Rescue', sex: 'Male', age: '20 weeks' }
    ];

    const result = await dogs.insertMany(sampleDogs);
    console.log(`${result.insertedCount} dogs inserted successfully.`);
  } catch (err) {
    console.error('Error seeding database:', err);
  } finally {
    await client.close();
  }
}

seedDatabase();
