/*** 
/    MILESTONE 1, AVERY REGIER @ SNHU VER 1.0 5/25/25
/    THIS PROJECT IS BASED ON CS340, A CRUD/MONGO/DASHBOARD APPLICATION USED TO
/    HELP GRAZIO SALVARE(MADE UP COMPANY, I THINK???) WITH ADOPTING RESCUE DOGS
/    THIS CODE USES VITE, REACT IN ORDER TO CONVERT THE PYTHON BASED ORIGINAL
/    CODE TO JAVASCRIPT USING HTML/CSS. THIS IS NOT THE FULLY COMPLETED PROJECT
/    BUT MOST OF THE FEATURES, EXCLUDING THE MAP (IT WAS DIFFICULT), SHOULD BE IMPLEMENTED
***/

// import utilities
import './style.css'
import Logo from '/logo.png'

// Initial dataset of rescue dogs
const data = [
  { breed: 'Water Rescue', sex: 'Male', age: '12 weeks', name: 'Buster' },
  { breed: 'Mountain Wilderness Rescue', sex: 'Female', age: '23 weeks', name: 'Daisy' },
  { breed: 'Disaster Individual Rescue', sex: 'Male', age: '43 weeks', name: 'Chop' },
];

// Track index of currently edited entry, null means no edit
let editIndex = null;

// Pie chart instance (to destroy and recreate when updating)
let pieChartInstance = null;

// Set up the HTML structure inside #app container
document.querySelector('#app').innerHTML = `
  <div>
    <h4 class="title">||| Grazio Salvare |||</h4>
    <a><img src="${Logo}" class="logo" alt="Logo"/></a>
    <div id="filters">
      <label>
        Breed:
        <select id="breedFilter"><option value="">All</option></select>
      </label>
      <label>
        Sex:
        <select id="sexFilter"><option value="">All</option></select>
      </label>
    </div>
    <form id="dogForm">
      <input type="text" id="breed" placeholder="Breed" required />
      <input type="text" id="sex" placeholder="Sex" required />
      <input type="text" id="age" placeholder="Age" required />
      <input type="text" id="name" placeholder="Name" required />
      <button type="submit">Add / Update</button>
    </form>
  </div>
`


/**
 * Render table rows from dataArray
 * @param {Array} dataArray - array of dog objects to show
 */
function renderTable(dataArray) {
  const tableBody = document.querySelector('#dataTable tbody');
  tableBody.innerHTML = '';

  dataArray.forEach((item, index) => {
    const row = document.createElement('tr');

    for (let key in item) {
      const cell = document.createElement('td');
      cell.textContent = item[key];
      row.appendChild(cell);
    }

    // Actions column with Edit and Delete buttons
    const actionsCell = document.createElement('td');
    actionsCell.innerHTML = `
      <button onclick="editEntry(${index})">Edit</button>
      <button onclick="deleteEntry(${index})">Delete</button>
    `;
    row.appendChild(actionsCell);
    tableBody.appendChild(row);
  });
}

/**
 * Populate the Breed and Sex filters dynamically based on data
 */
function populateFilters() {
  const breedSet = new Set();
  const sexSet = new Set();

  data.forEach(dog => {
    breedSet.add(dog.breed);
    sexSet.add(dog.sex);
  });

  const breedFilter = document.getElementById('breedFilter');
  const sexFilter = document.getElementById('sexFilter');

  breedFilter.innerHTML = '<option value="">All</option>';
  sexFilter.innerHTML = '<option value="">All</option>';

  breedSet.forEach(b => {
    breedFilter.innerHTML += `<option value="${b}">${b}</option>`;
  });
  sexSet.forEach(s => {
    sexFilter.innerHTML += `<option value="${s}">${s}</option>`;
  });
}

/**
 * Filter data based on search query and selected filters,
 * then update the table and pie chart
 */
function handleSearchAndFilter() {
  const query = document.getElementById('searchInput').value.toLowerCase();
  const selectedBreed = document.getElementById('breedFilter').value;
  const selectedSex = document.getElementById('sexFilter').value;

  const filtered = data.filter(item => {
    const matchesSearch = Object.values(item).some(val =>
      String(val).toLowerCase().includes(query)
    );
    const matchesBreed = selectedBreed ? item.breed === selectedBreed : true;
    const matchesSex = selectedSex ? item.sex === selectedSex : true;

    return matchesSearch && matchesSex && matchesBreed;
  });

  renderTable(filtered);
  renderPieChart(filtered); // Update pie chart with filtered data
}

/**
 * Sort table data by clicked column
 * @param {Event} event - click event on table header
 */
function handleSort(event) {
  const header = event.target;
  const column = header.getAttribute('data-column');
  const order = header.getAttribute('data-order');
  const newOrder = order === 'desc' ? 'asc' : 'desc';
  header.setAttribute('data-order', newOrder);

  const sorted = [...data].sort((a, b) => {
    if (a[column] > b[column]) return newOrder === 'asc' ? 1 : -1;
    if (a[column] < b[column]) return newOrder === 'asc' ? -1 : 1;
    return 0;
  });

  renderTable(sorted);
  renderPieChart(sorted); // Update pie chart on sort too
}

/**
 * Edit a specific dog entry by index, populating the form
 * @param {number} index - index of dog in data array
 */
window.editEntry = function (index) {
  const dog = data[index];
  document.getElementById('name').value = dog.name;
  document.getElementById('breed').value = dog.breed;
  document.getElementById('sex').value = dog.sex;
  document.getElementById('age').value = dog.age;
  editIndex = index;
};

/**
 * Delete a dog entry by index and update table, filters, and pie chart
 * @param {number} index - index of dog to delete
 */
window.deleteEntry = function (index) {
  data.splice(index, 1);
  renderTable(data);
  populateFilters();
  renderPieChart(data);
};

/**
 * Render or update pie chart for breed distribution based on filtered data
 * @param {Array} filteredData - current filtered data array
 */
function renderPieChart(filteredData) {
  // Count how many dogs per breed
  const breedCounts = filteredData.reduce((acc, dog) => {
    acc[dog.breed] = (acc[dog.breed] || 0) + 1;
    return acc;
  }, {});

  const breeds = Object.keys(breedCounts);
  const counts = Object.values(breedCounts);

  const ctx = document.getElementById('pieChart').getContext('2d');

  // Destroy existing chart instance to avoid overlap
  if (pieChartInstance) {
    pieChartInstance.destroy();
  }

  pieChartInstance = new Chart(ctx, {
    type: 'pie',
    data: {
      labels: breeds,
      datasets: [{
        label: 'Breed Distribution',
        data: counts,
        backgroundColor: [
          '#ff6384', '#36a2eb', '#cc65fe', '#ffce56', '#4bc0c0', '#9966ff', '#ff9f40'
        ],
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'bottom',
        },
        tooltip: {
          enabled: true,
        }
      }
    }
  });
}

/**
 * Initialize the app:
 * - Render initial table and filters
 * - Setup event listeners for form, search, filters, and sorting
 */
function init() {
  renderTable(data);
  populateFilters();
  renderPieChart(data);

  // Form submission for add/update dog entries
  document.getElementById('dogForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const dog = {
      breed: document.getElementById('breed').value,
      sex: document.getElementById('sex').value,
      age: document.getElementById('age').value,
      name: document.getElementById('name').value,
    };

    if (editIndex === null) {
      data.push(dog);
    } else {
      data[editIndex] = dog;
      editIndex = null;
    }

    renderTable(data);
    populateFilters();
    renderPieChart(data);  // Update pie chart after add/update
    this.reset();
  });

  // Search input keyup event to filter table and chart
  document.getElementById('searchInput').addEventListener('keyup', handleSearchAndFilter);

  // Filter selects change event to filter table and chart
  document.getElementById('breedFilter').addEventListener('change', handleSearchAndFilter);
  document.getElementById('sexFilter').addEventListener('change', handleSearchAndFilter);

  // Add sorting event listeners on table headers with data-column attribute
  const headers = document.querySelectorAll('th[data-column]');
  headers.forEach(header => header.addEventListener('click', handleSort));
}

init();
