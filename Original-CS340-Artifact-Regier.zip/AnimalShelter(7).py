from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter:
    def __init__(self, username, password, host, port, db, col):
        # Initializing the MongoClient. This helps to 
        USER = username
        PASS = password
        HOST = host
        PORT = port
        DB = db
        COL = col
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        # if there is an entry, insert and return true.
        if data is not None:
            self.database.animals.insert_one(data)  # data should be dictionary  
            return True
        # otherwise return false.
        else:
            return False
            raise Exception("Nothing to save, because data parameter is empty")

# Create method to implement the R in CRUD.
    def read(self, read):
        if read is not None:
        # if read is valid, read the data with its ID.
            try:
                data = self.database.animals.find(read)
                return list(data)
            except:
            # otherwise set an empty var.
                return []

# Create method to implement the U in CRUD.
    def update(self, data, update):
        # if both data and the new data are not empty, update and return how many were modified.
        if data and update is not None:
            result = self.database.animals.update_many(data, {"$set": update})
            return result.modified_count
        # if null return nothing
        else:
            raise Exception("No valid update found")
     
# Create method to implement the D in CRUD.
    def delete(self, delete):
        # if delete is not null then delete and return the count deleted.
        if delete is not None:
            data = self.database.animals.delete_one(delete).deleted_count
            return data
        else:
            raise Exception("No valid deletion found")
            
        
